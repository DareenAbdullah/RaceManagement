const startingMinutes = .1;
let time = startingMinutes * 60;
const countDown = document.getElementById('startSignal');
var interval; //fpr the start signal

var intervalRace; //for the stopwatch
var milliSec = 00;
var seconds = 00;
var appendMilli = document.getElementById("seconds");
var appendSeconds = document.getElementById("tens");
var buttonReset = document.getElementById("button-reset");


//Code for the startSignal
function startSignal(){
  if (time == 0){
    countDown.innerHTML = "start";
    countDown.style.cssText = "background-color:rgba(238, 88, 68, 0.933)";
    time = startingMinutes * 60;
  }
  else{
    interval = setInterval(updateCountdown, 1000);
  }
}

function updateCountdown(){
  if (time > 0){
    if (time == 4){ //Begin playing the mario sound track at this moment
      new Audio('marioKart.mp3').play();
    }
    const minutes = Math.floor(time / 60);
    let seconds  = time % 60;

    countDown.innerHTML = `${seconds}`;
    time--
  }
  else{
    countDown.innerHTML = "GO!!";
    countDown.style.cssText = "background-color:#267609";
    countDown.addEventListener("click", startSignal);
    clearInterval(interval);

	/*start the stop watches*/
	intervalRace = setInterval(startTimer);
  }
}

function startTimer(){
	seconds++;
	if (seconds < 9) {
		appendSeconds.innerHTML = "0" + seconds;
	}
	if (seconds > 9){
		appendSeconds.innerHTML = seconds;
	}
	if (seconds > 99){
		milliSec++;
		appendMilli.innerHTML = "0" + milliSec;
		seconds = 0;
		appendSeconds.innerHTML = "0" + 0;
	}
	if (milliSec > 9){
		appendMilli.innerHTML = milliSec;
	}
}

buttonReset.onclick = function(){
	clearInterval(intervalRace);
	seconds = "00";
	milliSec = "00";
	appendMilli.innerHTML = milliSec;
	appendSeconds.innerHTML = seconds;
}


/*let startBtn = document.getElementById('start');
let stopBtn = document.getElementById('stop');
let resetBtn = document.getElementById('reset');

let hour = 00;
let minute = 00;
let second = 00;
let count = 00;

startBtn.addEventListener('click', function () {
	timer = true;
	stopWatch();
});

stopBtn.addEventListener('click', function () {
	timer = false;
});

resetBtn.addEventListener('click', function () {
	timer = false;
	hour = 0;
	minute = 0;
	second = 0;
	count = 0;
	document.getElementById('hr').innerHTML = "00";
	document.getElementById('min').innerHTML = "00";
	document.getElementById('sec').innerHTML = "00";
	document.getElementById('count').innerHTML = "00";
});

function stopWatch() {
	if (timer) {
		count++;

		if (count == 100) {
			second++;
			count = 0;
		}

		if (second == 60) {
			minute++;
			second = 0;
		}

		if (minute == 60) {
			hour++;
			minute = 0;
			second = 0;
		}

		let hrString = hour;
		let minString = minute;
		let secString = second;
		let countString = count;

		if (hour < 10) {
			hrString = "0" + hrString;
		}

		if (minute < 10) {
			minString = "0" + minString;
		}

		if (second < 10) {
			secString = "0" + secString;
		}

		if (count < 10) {
			countString = "0" + countString;
		}

		document.getElementById('hr').innerHTML = hrString;
		document.getElementById('min').innerHTML = minString;
		document.getElementById('sec').innerHTML = secString;
		document.getElementById('count').innerHTML = countString;
		setTimeout(stopWatch, 10);
	}
}*/
